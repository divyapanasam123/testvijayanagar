import React, { Component } from "react";

class index extends Component {
  render() {
    return (
      <div>
        <div></div>
      </div>
    );
  }
}


const Indecators = () => {
  return(
    
  )
}

export default index;
