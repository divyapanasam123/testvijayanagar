import styled from 'styled-components';


export const ViewZoneContainer = styled.div`
    width:100%;
    height:100%;
`