import styled from "styled-components";

export const NotificationsBody = styled.div`
  height: 100%;
  width: 100%;
  background: #0f1726;
  padding: 1rem;
`;
