const baseUrl = `http://shark-api-v2.herokuapp.com/api`;

export const scheduleWipUrl = `${baseUrl}/wip/create`;

export const updateWipUrl = `${baseUrl}/wip/update`;

export const deleteWipUrl = `${baseUrl}/delete`;
