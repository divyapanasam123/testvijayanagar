export const workforceSelectWorkers = ({ workForce }) => workForce;
