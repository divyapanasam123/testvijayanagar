export const workforceSelectWorkers = ({ workForce: { workers } }) => workers;
