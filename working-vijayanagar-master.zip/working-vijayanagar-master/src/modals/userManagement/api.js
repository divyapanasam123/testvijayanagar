const baseUrl = `http://shark-api-v2.herokuapp.com/api`;

export const fetchUsersUrl = `https://8q83kl3bic.execute-api.ap-south-1.amazonaws.com/test/securityusers`;

export const deleteUserUrl = `${baseUrl}/user/delete`;

export const addUserUrl = `${baseUrl}/user/create`;

export const updateUserUrl = `${baseUrl}/user/update`;
