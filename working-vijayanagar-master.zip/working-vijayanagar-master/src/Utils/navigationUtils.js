export const goToZoneSelectionPage = (history) => {
  history.push("/add-zone");
};
